﻿**BREAST**

**CANCER**

**CLASSIFICATION**

**Table of Contents**

1. [About The Project](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#about-the-project)
   1. [Built With](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#built-with)
1. [Getting Started](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#getting-started)
   1. [Installation](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#installation)
1. [Usage](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#usage)
1. [Roadmap](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#roadmap)
1. [Contact](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#contact)
1. [Acknowledgments](https://github.com/othneildrew/Best-README-Template/blob/master/BLANK_README.md#acknowledgments)


















**1.About this project**

Neural networks, specifically deep learning models such as convolutional neural networks (CNNs), can play a vital role in the early detection of breast cancer. Breast cancer is the leading cause of cancer-related death in women. Early detection and accurate diagnosis are critical to improving patient outcomes. Convolutional neural networks (CNNs) have emerged as powerful tools for early detection of cancer due to their ability to learn and extract important features from clinical images. Using its algorithm and convolutional filters, CNNs can detect complex patterns and subtle abnormalities in mammograms, histopathology images, and other medical imaging modalities. CNNs, through extensive training on big data, can distinguish between soft tissue and soft tissue of the breast, enabling accurate classification and detection of tumors in the early days. CNN's layers enable the model to learn complex representations, helping to identify subtle features that are not easily visible to a human observer. By providing accurate and reliable analysis of cancer diagnosis, CNNs have the potential to support radiologists and physicians in diagnostic decisions, enable early detection, improved treatment planning and ultimately patient outcomes. In this project, we investigate the use of convolutional neural networks (CNNs) to classify breast cancer using histopathology images from the Kaggle dataset. We implemented a CNN model using Python and trained it on Google Colab using CUDA.

**2.Built with:**


Python

Google Colab

Google Drive

Pytorch

Cuda

GPU

Kaggle dataset







**2.Getting Started** 

1\. Open the NEWBCP.ipynb file from the repository 

2\. Run each and every code module one by one from step 1 to step 5

3\. Wait until step 5 completely executes, we’ll get the output image 10 times. Will take up to 2-3 minutes to run the step 5 (Training the model).

4\. After the training is finished –

1\. Setting up Kaggle API access: Collect Kaggle API access token. Navigate to Kaggle profile “Account” page. Find “create your API token”. Download token as a JSON file containing username and key.

2\. Save API token in Drive: Create a folder for Kaggle in Google Drive. Save a copy of the API token as a private file in this folder to access it easily

3\. Mount Google Drive to Colab: This will make sure we don’t have to download the data every time we restart runtime.![](Aspose.Words.fcdfb8e0-4a54-4b0a-af7b-70585ee6f374.001.png) 

















**3. Usage**

1\. Download the dataset in our local system and uploading few folders from the downloaded dataset to the google drive.

Note that in this step, we are just using few folders (images) from the entire dataset as it takes a very long time to process such a huge dataset. Here’s a screenshot of the folders we used –

![](Aspose.Words.fcdfb8e0-4a54-4b0a-af7b-70585ee6f374.002.png)

2\. Once the dataset is downloaded and connected, we start building the network and converting images to tensor 

3\. We then find the number of samples in each class

![](Aspose.Words.fcdfb8e0-4a54-4b0a-af7b-70585ee6f374.003.png)

**4. Roadmap**

4\. Splitting the dataset

![](Aspose.Words.fcdfb8e0-4a54-4b0a-af7b-70585ee6f374.004.png)

![](Aspose.Words.fcdfb8e0-4a54-4b0a-af7b-70585ee6f374.005.png)5. Output after splitting

6\. Getting 84% accuracy for 20 epochs 

![](Aspose.Words.fcdfb8e0-4a54-4b0a-af7b-70585ee6f374.006.png)


**5.Contact:**

Sanjana Lad

Pavan Kumar Kandregula

**6.Acknowledgement**

Guidance under Professor Lan Nygyen for the course Principles of Neural Systems

Master of Science in Computer Engineering 

California State University, Fullerton 
